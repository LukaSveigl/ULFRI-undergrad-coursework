package pins.data.ast;

import pins.common.report.*;
/**
 * A type.
 */
public abstract class AstType extends AST {

	public AstType(Location location) {
		super(location);
	}

}
