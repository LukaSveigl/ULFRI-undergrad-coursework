package pins.data.symbol;

public enum Token {

	EOF, DIGIT, OTHER
	
}
