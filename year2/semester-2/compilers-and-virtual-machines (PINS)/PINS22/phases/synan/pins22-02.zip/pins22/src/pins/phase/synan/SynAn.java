package pins.phase.synan;

import pins.phase.lexan.*;

public class SynAn implements AutoCloseable {

	public SynAn(LexAn lexan) {		
	}
	
	public void close() {
	}
	
	public void parser() {
	}

}
