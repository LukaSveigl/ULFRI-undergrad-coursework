/**
 * Compiler for the PINS'22 programming language.
 */
module pins {
}