/**
 * Lexical analysis.
 */
package pins.phase.lexan;