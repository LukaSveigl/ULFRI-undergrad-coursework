/**
 * Lexical symbols.
 */
package pins.data.symbol;