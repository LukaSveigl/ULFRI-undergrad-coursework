/**
 * Infrastructure for reporting all kinds of information to the user.
 */
package pins.common.report;