/**
 * Infrastructure for logging intermediate results.
 */
package pins.common.logger;