package pins.data.ast;

import pins.common.report.*;

/**
 * An expression.
 */
public abstract class AstExpr extends AST {

	public AstExpr(Location location) {
		super(location);
	}

}
