/**
 * Chucks of linear intermediate code.
 */
package pins.data.lin;
