/**
 * Data structures shared among different phases.
 */
package pins.data;