/**
 * Intermediate code generation.
 */
package pins.phase.imcgen;
