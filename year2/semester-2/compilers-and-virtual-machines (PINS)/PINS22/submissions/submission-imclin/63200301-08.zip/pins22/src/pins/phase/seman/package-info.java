/**
 * Semantic analysis.
 */
package pins.phase.seman;