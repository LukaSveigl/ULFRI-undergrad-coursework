/**
 * Intermediate code instructions.
 */
package pins.data.imc.code;
