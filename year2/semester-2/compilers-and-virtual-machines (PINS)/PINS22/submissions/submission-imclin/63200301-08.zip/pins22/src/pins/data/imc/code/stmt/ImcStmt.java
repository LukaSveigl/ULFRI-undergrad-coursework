package pins.data.imc.code.stmt;

import pins.data.imc.code.*;

/**
 * Intermediate code instruction denoting a statement.
 */
public abstract class ImcStmt extends ImcInstr {
}
