package pins.data.ast;

public interface AstName {
}
