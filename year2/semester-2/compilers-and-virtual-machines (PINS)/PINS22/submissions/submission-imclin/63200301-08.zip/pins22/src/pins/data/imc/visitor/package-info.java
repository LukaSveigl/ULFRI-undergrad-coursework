/**
 * Visitors for traversing intermediate code trees.
 */
package pins.data.imc.visitor;
