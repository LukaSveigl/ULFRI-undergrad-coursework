/**
 * Intermediate code linearization.
 */
package pins.phase.imclin;