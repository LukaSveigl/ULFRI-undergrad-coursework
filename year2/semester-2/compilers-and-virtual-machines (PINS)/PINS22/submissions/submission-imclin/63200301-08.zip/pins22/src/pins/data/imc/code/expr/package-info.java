/**
 * Intermediate code instructions denoting expressions.
 */
package pins.data.imc.code.expr;
