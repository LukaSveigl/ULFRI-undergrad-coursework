/**
 * Memory layout: frames and accesses.
 */
package pins.data.mem;
