/**
 * Memory layout: frames and accesses.
 */
package pins.phase.memory;