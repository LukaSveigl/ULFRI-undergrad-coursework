package pins.data.lin;

/**
 * An abstract chunk of linear code.
 */
public class LinChunk {
}
