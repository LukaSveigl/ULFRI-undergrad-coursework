/**
 * Representing types.
 */
package pins.data.typ;