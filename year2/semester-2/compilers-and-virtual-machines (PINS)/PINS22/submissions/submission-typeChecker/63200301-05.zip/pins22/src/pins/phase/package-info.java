/**
 * Compiler phases.
 */
package pins.phase;