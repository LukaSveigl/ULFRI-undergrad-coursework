/**
 * Syntax analysis.
 */
package pins.phase.synan;