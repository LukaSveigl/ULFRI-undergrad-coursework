/**
 * Intermediate code instructions denoting statements.
 */
package pins.data.imc.code.stmt;
