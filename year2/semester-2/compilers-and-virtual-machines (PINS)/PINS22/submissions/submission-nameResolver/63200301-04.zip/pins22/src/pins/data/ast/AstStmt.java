package pins.data.ast;

import pins.common.report.*;

/**
 * A statement.
 */
public abstract class AstStmt extends AST {

	public AstStmt(Location location) {
		super(location);
	}

}
