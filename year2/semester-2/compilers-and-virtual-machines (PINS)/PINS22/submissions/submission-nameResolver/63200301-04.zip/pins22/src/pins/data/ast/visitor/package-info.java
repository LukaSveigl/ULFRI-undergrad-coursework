/**
 * AST visitors.
 */
package pins.data.ast.visitor;