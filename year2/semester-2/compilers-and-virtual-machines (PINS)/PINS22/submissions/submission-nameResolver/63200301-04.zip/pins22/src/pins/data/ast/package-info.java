/**
 * Abstract syntax trees.
 */
package pins.data.ast;